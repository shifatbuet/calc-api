<?php

Route::post('calculate', 'CalculatorController@calculate');
